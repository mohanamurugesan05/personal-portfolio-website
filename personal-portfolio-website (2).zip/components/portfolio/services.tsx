"use client"

import { useRef } from "react"
import { 
  Palette, 
  Code2, 
  Smartphone, 
  PenTool, 
  Layers, 
  Zap,
  ArrowRight
} from "lucide-react"
import { motion, useInView } from "framer-motion"

const services = [
  {
    icon: Palette,
    title: "UI/UX Design",
    description: "Creating intuitive and visually stunning user interfaces that enhance user experience and drive engagement.",
    features: ["User Research", "Wireframing", "Visual Design", "Usability Testing"],
  },
  {
    icon: Code2,
    title: "Frontend Development",
    description: "Building responsive, performant, and accessible web applications using modern technologies and best practices.",
    features: ["React/Next.js", "TypeScript", "Tailwind CSS", "Performance Optimization"],
  },
  {
    icon: Smartphone,
    title: "Responsive Design",
    description: "Ensuring seamless experiences across all devices with mobile-first design approach and adaptive layouts.",
    features: ["Mobile-First", "Cross-Browser", "Adaptive Layouts", "Touch-Friendly"],
  },
  {
    icon: PenTool,
    title: "Brand Identity",
    description: "Crafting unique brand identities that communicate your values and resonate with your target audience.",
    features: ["Logo Design", "Brand Guidelines", "Visual Identity", "Brand Strategy"],
  },
  {
    icon: Layers,
    title: "Prototyping",
    description: "Creating interactive prototypes to visualize and test ideas before development, saving time and resources.",
    features: ["Interactive Prototypes", "User Flows", "Animation", "Feedback Integration"],
  },
  {
    icon: Zap,
    title: "Design Systems",
    description: "Building scalable design systems that ensure consistency and efficiency across all your digital products.",
    features: ["Component Libraries", "Style Guides", "Documentation", "Token Systems"],
  },
]

export function Services() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="services" className="py-20 lg:py-32 bg-secondary/50 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-primary/5 rounded-full blur-3xl pointer-events-none -translate-y-1/2" />
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        {/* Section Header */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4 backdrop-blur-sm border border-primary/20">
            Services
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4 text-balance">
            What I Offer
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto text-pretty">
            Comprehensive design and development services to bring your digital vision to life
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="group bg-background/80 backdrop-blur-sm rounded-2xl p-6 lg:p-8 border border-border/50 hover:border-primary/50 hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300"
            >
              {/* Icon */}
              <motion.div 
                whileHover={{ scale: 1.1, rotate: 5 }}
                className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary group-hover:shadow-lg group-hover:shadow-primary/25 transition-all duration-300"
              >
                <service.icon className="w-7 h-7 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
              </motion.div>

              {/* Title */}
              <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                {service.title}
              </h3>

              {/* Description */}
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                {service.description}
              </p>

              {/* Features */}
              <ul className="space-y-2 mb-6">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <motion.div 
                      whileHover={{ scale: 1.5 }}
                      className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" 
                    />
                    {feature}
                  </li>
                ))}
              </ul>

              {/* Learn More Link */}
              <a
                href="#contact"
                className="inline-flex items-center gap-2 text-sm font-medium text-primary group-hover:gap-3 transition-all"
              >
                Learn More
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
