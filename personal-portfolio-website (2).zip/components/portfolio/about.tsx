"use client"

import { useRef } from "react"
import { CheckCircle2, Award, Users, Briefcase } from "lucide-react"
import Image from "next/image"
import { motion, useInView } from "framer-motion"

const highlights = [
  "5+ Years of Professional Experience",
  "100+ Projects Successfully Delivered",
  "Award-Winning Design Portfolio",
  "Expertise in Modern Tech Stack",
]

const stats = [
  { icon: Award, value: "15+", label: "Design Awards" },
  { icon: Users, value: "50+", label: "Happy Clients" },
  { icon: Briefcase, value: "100+", label: "Projects Done" },
]

export function About() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="about" className="py-20 lg:py-32 bg-secondary/50 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-80 h-80 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        {/* Section Header */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4 backdrop-blur-sm border border-primary/20">
            About Me
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4 text-balance">
            Passionate About Creating Digital Excellence
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto text-pretty">
            Get to know the person behind the designs and development
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left - Image */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <motion.div 
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.3 }}
              className="relative rounded-2xl overflow-hidden shadow-2xl"
            >
              <Image
                src="https://images.unsplash.com/photo-1549692520-acc6669e2f0c?w=600&h=700&fit=crop"
                alt="Alex Morgan working"
                width={600}
                height={700}
                className="w-full h-auto object-cover"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/20 to-transparent" />
            </motion.div>

            {/* Experience badge */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: 0.4 }}
              whileHover={{ scale: 1.05 }}
              className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground rounded-2xl p-6 shadow-xl shadow-primary/25 backdrop-blur-sm"
            >
              <div className="text-4xl font-bold">5+</div>
              <div className="text-sm">Years of<br />Experience</div>
            </motion.div>

            {/* Decorative element */}
            <motion.div 
              animate={{ rotate: [0, 5, 0, -5, 0] }}
              transition={{ duration: 10, repeat: Infinity }}
              className="absolute -top-4 -left-4 w-24 h-24 border-4 border-primary/30 rounded-2xl" 
            />
          </motion.div>

          {/* Right - Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h3 className="text-2xl sm:text-3xl font-bold text-foreground mb-6">
              I&apos;m Alex Morgan, a Freelance UI/UX Designer & Frontend Developer based in San Francisco
            </h3>

            <p className="text-muted-foreground text-base leading-relaxed mb-6">
              With over 5 years of experience in the design industry, I specialize in creating beautiful, 
              functional, and user-centered digital experiences. My passion lies in transforming complex 
              problems into simple, intuitive, and elegant design solutions.
            </p>

            <p className="text-muted-foreground text-base leading-relaxed mb-8">
              I believe that great design is not just about how things look, but how they work. 
              Every project I take on is an opportunity to create something meaningful that makes 
              a real impact on users and businesses alike.
            </p>

            {/* Highlights */}
            <div className="space-y-3 mb-8">
              {highlights.map((item, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                  className="flex items-center gap-3 group"
                >
                  <motion.div whileHover={{ scale: 1.2, rotate: 10 }}>
                    <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                  </motion.div>
                  <span className="text-foreground font-medium group-hover:text-primary transition-colors">{item}</span>
                </motion.div>
              ))}
            </div>

            {/* Stats */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="grid grid-cols-3 gap-4 p-6 bg-background/80 backdrop-blur-sm rounded-2xl shadow-lg border border-border/50"
            >
              {stats.map((stat, index) => (
                <motion.div 
                  key={index}
                  whileHover={{ y: -5 }}
                  className="text-center"
                >
                  <motion.div whileHover={{ scale: 1.1, rotate: 5 }}>
                    <stat.icon className="w-8 h-8 text-primary mx-auto mb-2" />
                  </motion.div>
                  <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
