"use client"

import { useRef } from "react"
import { 
  Figma, 
  Palette, 
  Code2, 
  Globe, 
  Smartphone, 
  Layers,
  PenTool,
  Zap
} from "lucide-react"
import { motion, useInView } from "framer-motion"

const skills = [
  {
    category: "Design",
    items: [
      { name: "UI/UX Design", level: 95, icon: Palette },
      { name: "Figma", level: 90, icon: Figma },
      { name: "Adobe XD", level: 85, icon: PenTool },
      { name: "Prototyping", level: 88, icon: Layers },
    ],
  },
  {
    category: "Development",
    items: [
      { name: "HTML/CSS", level: 95, icon: Code2 },
      { name: "JavaScript", level: 88, icon: Zap },
      { name: "React/Next.js", level: 85, icon: Globe },
      { name: "Responsive Design", level: 92, icon: Smartphone },
    ],
  },
]

const tools = [
  "Figma",
  "Adobe XD",
  "Sketch",
  "Photoshop",
  "Illustrator",
  "VS Code",
  "GitHub",
  "Notion",
  "Framer",
  "Webflow",
]

function AnimatedProgressBar({ level, delay }: { level: number; delay: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, margin: "-50px" })

  return (
    <div ref={ref} className="h-3 bg-muted rounded-full overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        animate={isInView ? { width: `${level}%` } : { width: 0 }}
        transition={{ duration: 1.2, delay: delay, ease: "easeOut" }}
        className="h-full bg-gradient-to-r from-primary to-primary/80 rounded-full relative"
      >
        <motion.div 
          animate={{ x: ["-100%", "200%"] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
        />
      </motion.div>
    </div>
  )
}

export function Skills() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="skills" className="py-20 lg:py-32 bg-background relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-primary/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" ref={ref}>
        {/* Section Header */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4 backdrop-blur-sm border border-primary/20">
            My Skills
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4 text-balance">
            Skills & Expertise
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto text-pretty">
            A comprehensive toolkit of design and development skills honed over years of experience
          </p>
        </motion.div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 mb-16">
          {skills.map((category, catIndex) => (
            <motion.div 
              key={catIndex}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: catIndex * 0.2 }}
              className="bg-secondary/50 backdrop-blur-sm rounded-2xl p-6 lg:p-8 border border-border/50 hover:border-primary/30 hover:shadow-xl transition-all"
            >
              <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                <span className="w-2 h-8 bg-primary rounded-full"></span>
                {category.category} Skills
              </h3>
              <div className="space-y-6">
                {category.items.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <motion.div 
                          whileHover={{ scale: 1.1, rotate: 5 }}
                          className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center"
                        >
                          <skill.icon className="w-5 h-5 text-primary" />
                        </motion.div>
                        <span className="font-medium text-foreground">{skill.name}</span>
                      </div>
                      <span className="text-sm font-bold text-primary bg-primary/10 px-2 py-1 rounded-full">
                        {skill.level}%
                      </span>
                    </div>
                    <AnimatedProgressBar level={skill.level} delay={catIndex * 0.2 + skillIndex * 0.1} />
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tools & Technologies */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center"
        >
          <h3 className="text-xl font-bold text-foreground mb-6">Tools & Technologies</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {tools.map((tool, index) => (
              <motion.span
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.3, delay: 0.5 + index * 0.05 }}
                whileHover={{ scale: 1.05, y: -2 }}
                className="px-5 py-2.5 bg-secondary/50 backdrop-blur-sm rounded-full text-sm font-medium text-foreground border border-border/50 hover:bg-primary hover:text-primary-foreground hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all cursor-default"
              >
                {tool}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
